namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// Holds all mutable game data (score, missed eggs, speed) and
    /// encapsulates the rules that govern level progression and game-over.
    /// The Form never touches raw integers directly — it always goes through this class.
    /// </summary>
    public class GameState
    {
        // --- Tunable constants -------------------------------------------
        private const int InitialSpeed      = 8;
        private const int FastSpeed         = 12;
        private const int SpeedIncreaseAt   = 10;   // score threshold for speed boost
        private const int MaxMissedEggs     = 5;    // misses before game over
        // -----------------------------------------------------------------

        public int Score   { get; private set; }
        public int Missed  { get; private set; }
        public int Speed   { get; private set; }

        /// <summary>True when the player has missed more eggs than the allowed limit.</summary>
        public bool IsGameOver => Missed > MaxMissedEggs;

        public GameState()
        {
            Reset();
        }

        /// <summary>Increments the saved-egg counter and updates falling speed if needed.</summary>
        public void EggCaught()
        {
            Score++;
            if (Score > SpeedIncreaseAt)
                Speed = FastSpeed;
        }

        /// <summary>Increments the missed-egg counter.</summary>
        public void EggMissed()
        {
            Missed++;
        }

        /// <summary>Resets all counters and speed back to their starting values.</summary>
        public void Reset()
        {
            Score  = 0;
            Missed = 0;
            Speed  = InitialSpeed;
        }
    }
}
