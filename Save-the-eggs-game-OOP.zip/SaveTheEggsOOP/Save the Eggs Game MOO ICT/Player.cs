using System.Drawing;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// Represents the player-controlled chicken that catches falling eggs.
    /// Encapsulates movement state and sprite swapping.
    /// </summary>
    public class Player : GameObject
    {
        private const int MoveSpeed = 12;

        private bool _goLeft;
        private bool _goRight;

        public Player(PictureBox pictureBox) : base(pictureBox) { }

        /// <summary>
        /// Records that the left arrow key is pressed.
        /// </summary>
        public void SetMovingLeft(bool moving)  => _goLeft  = moving;

        /// <summary>
        /// Records that the right arrow key is pressed.
        /// </summary>
        public void SetMovingRight(bool moving) => _goRight = moving;

        /// <summary>
        /// Moves the player and updates the sprite to face the right direction.
        /// Call once per game-timer tick.
        /// </summary>
        /// <param name="formWidth">Client width of the form, used as the right boundary.</param>
        public void Update(int formWidth)
        {
            if (_goLeft && Left > 0)
            {
                Left -= MoveSpeed;
                Image = Properties.Resources.chicken_normal2;
            }

            if (_goRight && Left + Width < formWidth)
            {
                Left += MoveSpeed;
                Image = Properties.Resources.chicken_normal;
            }
        }

        /// <summary>
        /// Resets the player to its starting position and restores the normal sprite.
        /// </summary>
        public void ResetPosition(int formWidth)
        {
            Left  = formWidth / 2;
            Image = Properties.Resources.chicken_normal;
        }

        /// <summary>
        /// Switches to the hurt sprite when an egg is missed.
        /// </summary>
        public void ShowHurtSprite()
        {
            Image = Properties.Resources.chicken_hurt;
        }

        /// <summary>
        /// Stops all movement — typically called on game reset.
        /// </summary>
        public void StopMoving()
        {
            _goLeft  = false;
            _goRight = false;
        }
    }
}
