using System.Drawing;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// A short-lived visual effect shown at the point where an egg hits the ground.
    /// Uses its own dynamically-created PictureBox so the Designer stays clean.
    /// </summary>
    public class SplashEffect : GameObject
    {
        private const int SplashSize = 60;

        public SplashEffect() : base(CreatePictureBox()) { }

        private static PictureBox CreatePictureBox()
        {
            return new PictureBox
            {
                Size      = new Size(SplashSize, SplashSize),
                BackColor = Color.Transparent,
                SizeMode  = PictureBoxSizeMode.StretchImage
            };
        }

        /// <summary>
        /// Moves the splash to the position of the egg that just hit the ground
        /// and assigns the splash image.
        /// </summary>
        public void ShowAt(Point location)
        {
            PictureBox.Location = location;
            Image = Properties.Resources.splash;
        }
    }
}
