using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// Coordinates all game objects and implements the game loop.
    /// The Form delegates every game-logic decision to this class,
    /// keeping the UI layer free of any game rules.
    /// </summary>
    public class GameManager
    {
        // --- Dependencies injected by the Form ---------------------------
        private readonly Form        _form;
        private readonly Timer       _gameTimer;
        private readonly Player      _player;
        private readonly List<Egg>   _eggs;
        private readonly Label       _scoreLabel;
        private readonly Label       _missLabel;
        // -----------------------------------------------------------------

        private readonly GameState   _state;
        private readonly SplashEffect _splash;

        public GameManager(
            Form        form,
            Timer       gameTimer,
            Player      player,
            List<Egg>   eggs,
            Label       scoreLabel,
            Label       missLabel)
        {
            _form       = form;
            _gameTimer  = gameTimer;
            _player     = player;
            _eggs       = eggs;
            _scoreLabel = scoreLabel;
            _missLabel  = missLabel;

            _state  = new GameState();
            _splash = new SplashEffect();

            // Register the splash PictureBox with the form once
            _form.Controls.Add(_splash.PictureBox);
        }

        // ------------------------------------------------------------------
        // Input forwarding
        // ------------------------------------------------------------------

        public void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)  _player.SetMovingLeft(true);
            if (e.KeyCode == Keys.Right) _player.SetMovingRight(true);
        }

        public void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)  _player.SetMovingLeft(false);
            if (e.KeyCode == Keys.Right) _player.SetMovingRight(false);
        }

        // ------------------------------------------------------------------
        // Game loop — called by the timer Tick event
        // ------------------------------------------------------------------

        public void Tick()
        {
            UpdateHUD();
            _player.Update(_form.ClientSize.Width);
            UpdateEggs();
            CheckGameOver();
        }

        // ------------------------------------------------------------------
        // Private helpers
        // ------------------------------------------------------------------

        private void UpdateHUD()
        {
            _scoreLabel.Text = "Saved: "  + _state.Score;
            _missLabel.Text  = "Missed: " + _state.Missed;
        }

        private void UpdateEggs()
        {
            foreach (Egg egg in _eggs)
            {
                egg.Fall(_state.Speed);

                if (egg.HasFallenOff(_form.ClientSize.Height))
                {
                    _splash.ShowAt(egg.PictureBox.Location);
                    egg.Respawn(_form.ClientSize.Width);
                    _state.EggMissed();
                    _player.ShowHurtSprite();
                }
                else if (_player.IntersectsWith(egg))
                {
                    egg.Respawn(_form.ClientSize.Width);
                    _state.EggCaught();
                }
            }
        }

        private void CheckGameOver()
        {
            if (_state.IsGameOver)
            {
                _gameTimer.Stop();
                MessageBox.Show(
                    "Game Over!" + Environment.NewLine +
                    "We've lost good Eggs!" + Environment.NewLine +
                    "Click ok to retry");
                StartGame();
            }
        }

        // ------------------------------------------------------------------
        // Game lifecycle
        // ------------------------------------------------------------------

        /// <summary>
        /// Resets the game state and all objects, then starts the timer.
        /// Safe to call both at startup and after game-over.
        /// </summary>
        public void StartGame()
        {
            _state.Reset();
            _player.ResetPosition(_form.ClientSize.Width);
            _player.StopMoving();

            foreach (Egg egg in _eggs)
                egg.Respawn(_form.ClientSize.Width);

            _gameTimer.Start();
        }
    }
}
