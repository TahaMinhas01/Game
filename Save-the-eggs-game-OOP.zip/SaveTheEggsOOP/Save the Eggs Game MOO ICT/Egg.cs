using System;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// Represents a single falling egg.
    /// Owns its own random positioning so each egg behaves independently.
    /// </summary>
    public class Egg : GameObject
    {
        private readonly Random _randX;
        private readonly Random _randY;

        public Egg(PictureBox pictureBox, Random randX, Random randY)
            : base(pictureBox)
        {
            _randX = randX;
            _randY = randY;
        }

        /// <summary>
        /// Moves the egg downward by <paramref name="speed"/> pixels.
        /// </summary>
        public void Fall(int speed)
        {
            Top += speed;
        }

        /// <summary>
        /// Returns true when the egg has passed the bottom edge of the form.
        /// </summary>
        public bool HasFallenOff(int formHeight)
        {
            return Top + Height > formHeight;
        }

        /// <summary>
        /// Teleports the egg to a new random position above the top of the form.
        /// Call this when the egg is caught or missed.
        /// </summary>
        public void Respawn(int formWidth)
        {
            Top  = _randY.Next(80, 300) * -1;
            Left = _randX.Next(5, formWidth - Width);
        }
    }
}
