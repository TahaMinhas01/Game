namespace Save_the_Eggs_Game_MOO_ICT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.eggPictureBox1 = new System.Windows.Forms.PictureBox();
            this.eggPictureBox2 = new System.Windows.Forms.PictureBox();
            this.eggPictureBox3 = new System.Windows.Forms.PictureBox();
            this.playerPictureBox = new System.Windows.Forms.PictureBox();
            this.txtScore = new System.Windows.Forms.Label();
            this.txtMiss = new System.Windows.Forms.Label();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // eggPictureBox1
            // 
            this.eggPictureBox1.Image = global::Save_the_Eggs_Game_MOO_ICT.Properties.Resources.egg;
            this.eggPictureBox1.Location = new System.Drawing.Point(71, 122);
            this.eggPictureBox1.Name = "eggPictureBox1";
            this.eggPictureBox1.Size = new System.Drawing.Size(40, 50);
            this.eggPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eggPictureBox1.TabIndex = 0;
            this.eggPictureBox1.TabStop = false;
            this.eggPictureBox1.Tag = "eggs";
            // 
            // eggPictureBox2
            // 
            this.eggPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("eggPictureBox2.Image")));
            this.eggPictureBox2.Location = new System.Drawing.Point(257, 122);
            this.eggPictureBox2.Name = "eggPictureBox2";
            this.eggPictureBox2.Size = new System.Drawing.Size(40, 50);
            this.eggPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eggPictureBox2.TabIndex = 0;
            this.eggPictureBox2.TabStop = false;
            this.eggPictureBox2.Tag = "eggs";
            // 
            // eggPictureBox3
            // 
            this.eggPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("eggPictureBox3.Image")));
            this.eggPictureBox3.Location = new System.Drawing.Point(465, 122);
            this.eggPictureBox3.Name = "eggPictureBox3";
            this.eggPictureBox3.Size = new System.Drawing.Size(40, 50);
            this.eggPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eggPictureBox3.TabIndex = 0;
            this.eggPictureBox3.TabStop = false;
            this.eggPictureBox3.Tag = "eggs";
            // 
            // playerPictureBox
            // 
            this.playerPictureBox.Image = global::Save_the_Eggs_Game_MOO_ICT.Properties.Resources.chicken_normal;
            this.playerPictureBox.Location = new System.Drawing.Point(257, 619);
            this.playerPictureBox.Name = "playerPictureBox";
            this.playerPictureBox.Size = new System.Drawing.Size(85, 80);
            this.playerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerPictureBox.TabIndex = 0;
            this.playerPictureBox.TabStop = false;
            // 
            // txtScore
            // 
            this.txtScore.AutoSize = true;
            this.txtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore.Location = new System.Drawing.Point(12, 9);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(91, 24);
            this.txtScore.TabIndex = 1;
            this.txtScore.Text = "Saved: 0";
            // 
            // txtMiss
            // 
            this.txtMiss.AutoSize = true;
            this.txtMiss.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiss.Location = new System.Drawing.Point(503, 9);
            this.txtMiss.Name = "txtMiss";
            this.txtMiss.Size = new System.Drawing.Size(99, 24);
            this.txtMiss.TabIndex = 1;
            this.txtMiss.Text = "Missed: 0";
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.MainGameTimerEvent);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(614, 701);
            this.Controls.Add(this.txtMiss);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.playerPictureBox);
            this.Controls.Add(this.eggPictureBox3);
            this.Controls.Add(this.eggPictureBox2);
            this.Controls.Add(this.eggPictureBox1);
            this.Name = "Form1";
            this.Text = "Save the Eggs Game MOO ICT";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eggPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox eggPictureBox1;
        private System.Windows.Forms.PictureBox eggPictureBox2;
        private System.Windows.Forms.PictureBox eggPictureBox3;
        private System.Windows.Forms.PictureBox playerPictureBox;
        private System.Windows.Forms.Label txtScore;
        private System.Windows.Forms.Label txtMiss;
        private System.Windows.Forms.Timer GameTimer;
    }
}
