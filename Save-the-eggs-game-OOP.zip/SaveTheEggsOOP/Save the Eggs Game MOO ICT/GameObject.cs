using System.Drawing;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// Abstract base class for all visual game objects.
    /// Wraps a WinForms PictureBox and exposes game-friendly properties.
    /// </summary>
    public abstract class GameObject
    {
        // The underlying WinForms control — Designer still manages the form layout
        public PictureBox PictureBox { get; protected set; }

        public int Left
        {
            get => PictureBox.Left;
            set => PictureBox.Left = value;
        }

        public int Top
        {
            get => PictureBox.Top;
            set => PictureBox.Top = value;
        }

        public int Width  => PictureBox.Width;
        public int Height => PictureBox.Height;

        public Rectangle Bounds => PictureBox.Bounds;

        public Image Image
        {
            get => PictureBox.Image;
            set => PictureBox.Image = value;
        }

        protected GameObject(PictureBox pictureBox)
        {
            PictureBox = pictureBox;
        }

        /// <summary>
        /// Checks axis-aligned bounding-box intersection with another GameObject.
        /// </summary>
        public bool IntersectsWith(GameObject other)
        {
            return Bounds.IntersectsWith(other.Bounds);
        }
    }
}
