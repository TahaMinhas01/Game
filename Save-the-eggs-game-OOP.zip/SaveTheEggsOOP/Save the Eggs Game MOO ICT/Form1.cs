using System.Collections.Generic;
using System.Windows.Forms;

namespace Save_the_Eggs_Game_MOO_ICT
{
    /// <summary>
    /// WinForms entry point.
    /// This class is intentionally kept thin — it only wires the Designer-generated
    /// controls to the OOP game objects and forwards UI events to GameManager.
    /// All game rules live in GameManager, GameState, Player, Egg, and SplashEffect.
    /// </summary>
    public partial class Form1 : Form
    {
        private GameManager _gameManager;

        public Form1()
        {
            InitializeComponent();
            InitialiseGame();
        }

        /// <summary>
        /// Builds the object graph and hands control to GameManager.
        /// Called once, after InitializeComponent() has created the controls.
        /// </summary>
        private void InitialiseGame()
        {
            // Wrap Designer controls in OOP objects
            Player player = new Player(playerPictureBox);

            List<Egg> eggs = new List<Egg>
            {
                new Egg(eggPictureBox1, new System.Random(), new System.Random()),
                new Egg(eggPictureBox2, new System.Random(), new System.Random()),
                new Egg(eggPictureBox3, new System.Random(), new System.Random()),
            };

            _gameManager = new GameManager(
                form:        this,
                gameTimer:   GameTimer,
                player:      player,
                eggs:        eggs,
                scoreLabel:  txtScore,
                missLabel:   txtMiss);

            _gameManager.StartGame();
        }

        // ------------------------------------------------------------------
        // Event handlers — purely forward to GameManager
        // ------------------------------------------------------------------

        private void MainGameTimerEvent(object sender, System.EventArgs e)
        {
            _gameManager.Tick();
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            _gameManager.OnKeyDown(e);
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            _gameManager.OnKeyUp(e);
        }
    }
}
